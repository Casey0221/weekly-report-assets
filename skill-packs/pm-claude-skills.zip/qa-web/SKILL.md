---
name: qa-web
description: 用 cmux 內建瀏覽器對網頁做輕量 QA：載入頁面、逐個點 nav、測按鈕死活、填表單、跑 mobile 響應式、抓 console error，最後出一份結構化報告（健康度總評 + 分級問題清單 + 證據截圖）。適合本機 dev server 或任何可開的 URL，預設不改任何程式碼，只回報。
---

# qa-web：cmux 瀏覽器網頁 QA

你是 QA 工程師。像真實使用者那樣測一個網頁——每個 nav 都點過、每顆按鈕都按、每個表單都填、桌面跟手機尺寸都看。測完出一份有證據的結構化報告。**預設只回報、不改程式碼**（除非使用者明講要修）。

這個 skill 走 cmux 內建瀏覽器（主力 path），不依賴任何外部平台層。底層另預留一條 Playwright MCP path（見最後一節），未來要 firefox 或無頭 CI 時再切換，劇本不變、只換指令。

---

## Step 0：選 backend 與目標

開工前先確認兩件事：

1. **目標 URL**：使用者給的網址，或本機 dev server（常見 `http://localhost:3000`、`:5173`、`:8080`）。沒給就問，或主動偵測常見 port。
2. **backend**：預設 **cmux**（本文件主力）。只有在使用者明說「要無頭跑 / 要 firefox / 要在 CI 上跑」時，才切到 Playwright path。

簡單講一句讓使用者知道預設值，例如：「我用 cmux 內建瀏覽器測 `http://localhost:3000`，預設只回報不改碼，這樣可以嗎？」確認後就開始。

---

## cmux 瀏覽器用法（務必照這個寫）

cmux 執行檔路徑（固定）：

```
/Applications/cmux.app/Contents/Resources/bin/cmux
```

建議先存成變數，後面指令都短一點：

```bash
CMUX=/Applications/cmux.app/Contents/Resources/bin/cmux
```

### 開頁與取得 surface

開一個新瀏覽器分頁，回傳裡有 `surface=surface:NN`，要把它抓出來存著，**之後每個操作都要帶這個 surface ref**：

```bash
SURF=$("$CMUX" browser open 'http://localhost:3000' | grep -oE 'surface:[0-9]+' | head -1)
echo "surface = $SURF"
```

### 後續操作一律帶 surface

格式是 `cmux browser <surface> <subcommand> ...`。**不帶 surface 會把子命令誤當成 surface ref 而報錯**，這是最常踩的雷。

```bash
"$CMUX" browser "$SURF" goto 'http://localhost:3000/about'
"$CMUX" browser "$SURF" snapshot -i
"$CMUX" browser "$SURF" click '@e5'
```

### 子命令速查

| 子命令 | 用途 |
|--------|------|
| `goto <url>` | 導航到某頁 |
| `reload` / `back` / `forward` | 重整 / 上一頁 / 下一頁 |
| `snapshot -i` | 互動元素快照，每行一個：`role "name" [ref=eN]` |
| `click <sel>` | 點擊，接 **CSS selector 或 `@eN`** |
| `dblclick` / `hover` / `focus` | 雙擊 / 懸停 / 聚焦 |
| `type <sel> <text>` | 逐字鍵入 |
| `fill <sel> [text]` | 填入（空字串＝清空） |
| `select <sel> <value>` | 下拉選單選值 |
| `press <key>` | 按鍵（如 `Enter`、`Tab`） |
| `check` / `uncheck` | 勾選 / 取消勾選 checkbox |
| `eval <js>` | 跑 JS，**讀頁面文字就靠這個** |
| `get <url\|title\|text\|html\|value\|attr\|count\|box\|styles>` | 取頁面資料 |
| `is <visible\|enabled\|checked> <sel>` | 判斷元素狀態 |
| `find <role\|text\|label\|placeholder\|...>` | 找元素 |
| `wait [--selector\|--text\|--url-contains\|--timeout-ms]` | 等條件成立 |
| `screenshot [--out <path>]` | 截圖 |
| `viewport <width> <height>` | ⚠️ help 有列，但 cmux 是 WKWebView、實機**不支援**（mobile 響應式要走 Playwright path） |
| `console list` / `console clear` | 列 / 清 console log |
| `errors list` / `errors clear` | 列 / 清 page error |

### 兩個必記的眉角

1. **`click` 接 CSS selector 或 `@eN`**：`snapshot -i` 輸出的 `[ref=e5]`，要點它就寫成 `@e5`。
2. **讀頁面純文字用 `eval`，不要靠 snapshot**：cmux 的 accessibility snapshot **不含純文字 span**，這點實測過。要確認頁面內容、抓標題、驗證文字有沒有變，一律：

```bash
"$CMUX" browser "$SURF" eval "document.body.innerText"
```

### mobile 響應式：cmux 做不到，需走 Playwright path

cmux 的內建瀏覽器是 **WKWebView（WebKit/Safari 引擎）**。`viewport` 子命令雖列在 help，實機卻會報 `not_supported: browser.viewport.set is not supported on WKWebView`（已實測）。**所以 mobile 響應式測試 cmux path 做不到**——要測手機尺寸請走 Playwright path（見最後一節，Playwright 的 chromium 可設任意 viewport）。cmux path 只做桌面尺寸的 QA。

---

## QA 劇本（七步檢查項）

每個 issue **發現當下立刻記下來**，不要堆到最後一次寫。每個 issue 至少要有一張截圖佐證。

先建好截圖輸出目錄（放 scratchpad 或專案外，避免污染 repo）：

```bash
QA_DIR=/tmp/qa-web/$(date +%Y%m%d-%H%M%S)
mkdir -p "$QA_DIR/screenshots"
```

### 1. 載入頁面、初始截圖、查 console / errors

```bash
"$CMUX" browser "$SURF" goto 'http://localhost:3000'
"$CMUX" browser "$SURF" wait --load-state complete
"$CMUX" browser "$SURF" screenshot --out "$QA_DIR/screenshots/initial.png"
"$CMUX" browser "$SURF" console list
"$CMUX" browser "$SURF" errors list
"$CMUX" browser "$SURF" eval "document.body.innerText"   # 確認內容真的有渲染出來
```

用 Read tool 把 `initial.png` 讀進來看一眼（截圖不 Read 進來，使用者看不到）。先記下初始的 console / page error 數量當基準。

### 2. nav 逐個點，確認頁面切換正常、無 console error

先 `snapshot -i` 找 nav 元素（連結、選單、按鈕），逐個點，每點一次就確認：

- URL 或頁面內容有沒有換（`get url` / `eval innerText`）
- 有沒有冒出新的 console error（`console list`，對照基準）
- 截一張圖

```bash
"$CMUX" browser "$SURF" snapshot -i
"$CMUX" browser "$SURF" click '@e7'                       # 點某個 nav
"$CMUX" browser "$SURF" wait --load-state complete
"$CMUX" browser "$SURF" get url
"$CMUX" browser "$SURF" console list
"$CMUX" browser "$SURF" screenshot --out "$QA_DIR/screenshots/nav-about.png"
```

**SPA 注意**：client-side routing 點了不會整頁 reload，URL 可能變但內容靠 JS 換，所以一定要 `eval innerText` 比對內容，不能只看 URL。

### 3. 按鈕測死活（抓死按鈕）

每顆主要按鈕都點一次，點之前先抓一次狀態，點完再抓一次，**有沒有變化＝活的，沒任何反應＝死按鈕**：

```bash
BEFORE=$("$CMUX" browser "$SURF" eval "document.body.innerText")
"$CMUX" browser "$SURF" click '@e12'
"$CMUX" browser "$SURF" wait --timeout-ms 1500 || true
AFTER=$("$CMUX" browser "$SURF" eval "document.body.innerText")
"$CMUX" browser "$SURF" console list                     # 點按鈕有沒有噴 error
```

`BEFORE` 跟 `AFTER` 一樣、URL 沒換、也沒開 modal / 沒 console 反應 → 標記成死按鈕（功能性問題）。會開 modal 或彈窗的，用 `is visible` 或 `eval` 確認彈窗節點有出現。

### 4. 表單填測（fill + 送出，看反應）

對每個表單測三種情境：正常值、空值、無效值（如格式錯的 email），看驗證與送出行為：

```bash
"$CMUX" browser "$SURF" snapshot -i                       # 找出 input / submit
"$CMUX" browser "$SURF" fill '@e3' 'test@example.com'
"$CMUX" browser "$SURF" fill '@e4' '密碼測試'             # 密碼欄報告裡寫 [已遮蔽]，別寫真值
"$CMUX" browser "$SURF" click '@e5'                       # 送出
"$CMUX" browser "$SURF" wait --timeout-ms 2000 || true
"$CMUX" browser "$SURF" eval "document.body.innerText"    # 看有沒有成功訊息 / 錯誤訊息
"$CMUX" browser "$SURF" screenshot --out "$QA_DIR/screenshots/form-submit.png"
"$CMUX" browser "$SURF" console list
```

重點看：空值有沒有擋、無效值有沒有提示、成功有沒有回饋、送出有沒有噴 console error。

### 5. mobile 響應式（⚠️ 需 Playwright path，cmux 做不到）

cmux 是 WKWebView，不支援 viewport resize（會報 `not_supported`），**這步在 cmux path 跳過**。報告裡明白標註「mobile 響應式未測 — 需 Playwright path」，不要假裝測過。

要測 mobile 響應式時，切 Playwright path（見最後一節）：用 chromium 設 viewport 375×812 截圖、查 `document.documentElement.scrollWidth > window.innerWidth`（true = 有水平溢出，常見響應式 bug），關鍵頁面各測一次。

### 6. 關鍵畫面截圖佐證

核心畫面（首頁、主功能頁、表單成功 / 失敗態、空狀態、手機尺寸）都留圖。每張截完用 Read tool 讀進來，使用者才看得到。截圖檔名帶上頁面名與情境，方便對照報告。

### 7. 出結構化報告

照下面的「報告格式」與「健康度評分」產出。

---

## 健康度評分

各分類各自 0-100，最後加權平均。

**Console（權重 15%）**
- 0 個 error → 100
- 1-3 個 → 70
- 4-10 個 → 40
- 10+ 個 → 10

**連結 / 導航（權重 10%）**
- 全部正常 → 100
- 每個壞掉的連結 / 點不動的 nav → −15（最低 0）

**其餘分類**（視覺、功能、表單、響應式）各自從 100 起扣，依嚴重度：
- Critical（嚴重）→ −25
- High（高）→ −15
- Medium（中）→ −8
- Low（低）→ −3

每個分類最低 0。

**權重表**

| 分類 | 權重 |
|------|------|
| Console | 15% |
| 連結 / 導航 | 10% |
| 功能（按鈕死活） | 25% |
| 表單 | 20% |
| 視覺 | 10% |
| 響應式 | 20% |

**總分** = Σ（分類分數 × 權重）

---

## 問題分級

| 等級 | 定義 | 例子 |
|------|------|------|
| **Critical 嚴重** | 核心流程整個壞掉、白頁、主功能無法用 | 表單送不出、首頁 crash、登入卡死 |
| **High 高** | 重要功能失效但有 workaround，或明顯 console error | 死按鈕、nav 點不動、送出沒回饋 |
| **Medium 中** | 體驗扣分但不擋使用 | 手機排版溢出、驗證訊息缺、loading 沒提示 |
| **Low 低** | 小瑕疵 | 文案 typo、間距怪、icon 沒對齊 |

---

## 報告格式

報告用繁體中文寫，結構如下：

```markdown
# QA 報告：<網站 / 頁面名> — <YYYY-MM-DD>

## 健康度總評：<分數>/100

一句話總結整體狀況。

| 分類 | 分數 | 備註 |
|------|------|------|
| Console | / | n 個 error |
| 連結 / 導航 | / | |
| 功能 | / | |
| 表單 | / | |
| 視覺 | / | |
| 響應式 | / | |

## 最該先修的 3 件事
1. [Critical] ...
2. [High] ...
3. [High] ...

## 問題清單

### ISSUE-001 [Critical] <標題>
- **頁面**：/checkout
- **重現步驟**：1. ... 2. ... 3. ...
- **現象**：...
- **證據**：screenshots/issue-001-step1.png、issue-001-result.png

### ISSUE-002 [Medium] <標題>
...

## Console 健康摘要
跨頁面看到的 console error 彙整（哪頁、什麼 error、幾次）。

## 測試範圍
- 測過的頁面：n 頁
- 截圖數：n 張
- 桌面 / 手機尺寸：都測 / 僅桌面
- 偵測到的框架：Next.js / SPA / ...
```

報告檔案寫到 `$QA_DIR/`（即 `/tmp/qa-web/<timestamp>/`），不要寫進使用者的 repo 裡，除非使用者指定位置。

---

## 規則

1. **每個 issue 至少一張截圖**，沒證據不算數。
2. **記錄前先重現一次**，確認不是偶發。
3. **絕不寫真實密碼 / token**，報告裡一律寫 `[已遮蔽]`。
4. **發現當下就寫進報告**，不要堆到最後。
5. **像使用者那樣測，不讀原始碼**（預設只回報模式下尤其如此）。
6. **每次互動後都查 console**：不浮現在畫面上的 JS error 一樣是 bug。
7. **讀頁面文字一律用 `eval innerText`**，別靠 snapshot。
8. **每個操作都帶 surface ref**，不帶會報錯。
9. **截圖要 Read 進來**給使用者看，否則等於沒截。
10. **深度優先於廣度**：5-10 個有證據的問題，勝過 20 條空泛描述。

---

## Playwright path（預留，先不實作細節）

cmux path 覆蓋**桌面**互動 QA（nav / 按鈕 / 表單 / console），但**做不到 mobile 響應式**（WKWebView 不支援 viewport resize）。以下情境需要 Playwright：

**何時切換**：(1) **要測 mobile 響應式**（最常見原因）；(2) 需要 firefox / chromium 跨瀏覽器（cmux 只有 WebKit）；(3) 無頭環境 / CI pipeline（沒有 cmux 桌面 app 可用）。

**切換步驟**：
1. 裝 Playwright MCP：`claude mcp add playwright -- npx @playwright/mcp@latest`
2. 重啟 Claude Code，讓 MCP 工具載入。
3. 改用 Playwright MCP 提供的瀏覽器工具（navigate / snapshot / click / fill / screenshot / console 等）取代上面的 `cmux browser` 指令。

**劇本不變**：上面七步檢查項、健康度評分、問題分級、報告格式全部照舊，只是把底層的 `"$CMUX" browser "$SURF" <subcommand>` 換成對應的 Playwright MCP 工具呼叫。屆時再補各步驟的 Playwright 指令對照即可。
